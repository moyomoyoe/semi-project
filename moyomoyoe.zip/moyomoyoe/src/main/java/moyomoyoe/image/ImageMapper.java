package moyomoyoe.image;

public interface ImageMapper {
}
